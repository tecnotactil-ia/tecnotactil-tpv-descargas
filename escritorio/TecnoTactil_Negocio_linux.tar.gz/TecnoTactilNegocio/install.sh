#!/usr/bin/env bash
# ============================================================================
# TecnoTáctil Negocio — INSTALADOR / ACTUALIZADOR (Linux).
#
# Detecta si la app ya está instalada:
#   - Si NO existe → instalación limpia.
#   - Si EXISTE  → actualización preservando la BD y la configuración.
#
# Uso:
#   sudo bash install.sh                     # sistema (todos los users), en /opt
#   bash install.sh                          # solo tu user, en ~/.local/share
#   bash install.sh --prefix /ruta           # ubicación explícita
#
# Este script se ejecuta desde DENTRO del bundle desempaquetado (tar.gz) o
# desde el propio repo tras build_linux.sh.
# ============================================================================
set -euo pipefail

APP_ID="tecnotactil-negocio"
APP_NAME="TecnoTáctil Negocio"
BIN_NAME="tecnotactil-negocio"

BOLD=$(tput bold 2>/dev/null || echo ""); NC=$(tput sgr0 2>/dev/null || echo "")
YELLOW=$(tput setaf 3 2>/dev/null || echo ""); GREEN=$(tput setaf 2 2>/dev/null || echo "")
CYAN=$(tput setaf 6 2>/dev/null || echo ""); RED=$(tput setaf 1 2>/dev/null || echo "")

# --- Parámetros ---
PREFIX=""
while [ $# -gt 0 ]; do
    case "$1" in
        --prefix) PREFIX="$2"; shift 2 ;;
        -h|--help)
            grep -E '^# ' "$0" | sed 's/^# //'; exit 0 ;;
        *) echo "Opción desconocida: $1"; exit 1 ;;
    esac
done

# --- Directorio origen (donde está el binario) ---
SRC="$(cd "$(dirname "$0")" && pwd)"
if [ ! -x "$SRC/$BIN_NAME" ]; then
    echo "${RED}No encuentro $BIN_NAME en $SRC${NC}" >&2
    echo "Ejecuta este script desde la carpeta desempaquetada del bundle." >&2
    exit 1
fi

# --- Ubicación destino ---
if [ -z "$PREFIX" ]; then
    if [ "$(id -u)" = "0" ]; then
        PREFIX="/opt/tecnotactil"
        DESKTOP_DIR="/usr/share/applications"
        SCOPE="system"
    else
        PREFIX="$HOME/.local/share/tecnotactil"
        DESKTOP_DIR="$HOME/.local/share/applications"
        SCOPE="user"
    fi
fi
INSTALL_DIR="$PREFIX/TecnoTactilNegocio"
DESKTOP_FILE="$DESKTOP_DIR/TecnoTactilNegocio.desktop"

echo "${BOLD}${CYAN}== $APP_NAME — Instalador ==${NC}"
echo "Origen: $SRC"
echo "Destino: $INSTALL_DIR (scope $SCOPE)"

# --- Detectar instalación previa ---
UPGRADE=0
OLD_VERSION=""
NEW_VERSION=""
[ -f "$SRC/version.txt" ] && NEW_VERSION=$(cat "$SRC/version.txt" 2>/dev/null || true)
if [ -x "$INSTALL_DIR/$BIN_NAME" ]; then
    UPGRADE=1
    OLD_VERSION=$(cat "$INSTALL_DIR/version.txt" 2>/dev/null || echo "desconocida")
    echo "${YELLOW}Detectada instalación previa (v$OLD_VERSION → v${NEW_VERSION:-nueva}) — modo ACTUALIZACIÓN${NC}"
fi

# --- Matar procesos en ejecución (upgrade requiere sacar el binario del RAM) ---
kill_processes() {
    local killed=0
    # Buscar por ruta absoluta del binario (más preciso que por nombre)
    local target_path="$INSTALL_DIR/$BIN_NAME"
    # pgrep -f busca en la cmdline completa
    for pid in $(pgrep -f "$target_path" 2>/dev/null || true); do
        echo "  → matando PID $pid ($(ps -p $pid -o cmd= 2>/dev/null | head -c 80))"
        kill "$pid" 2>/dev/null || true
        killed=1
    done
    # También el firefox embebido que abrió (por si quedó huérfano)
    for pid in $(pgrep -f "$INSTALL_DIR/firefox/firefox" 2>/dev/null || true); do
        kill "$pid" 2>/dev/null || true
        killed=1
    done
    if [ $killed -eq 1 ]; then
        sleep 2
        # SIGKILL a los que sigan vivos
        for pid in $(pgrep -f "$target_path" 2>/dev/null || true); do
            kill -9 "$pid" 2>/dev/null || true
        done
        for pid in $(pgrep -f "$INSTALL_DIR/firefox/firefox" 2>/dev/null || true); do
            kill -9 "$pid" 2>/dev/null || true
        done
    fi
}

if [ $UPGRADE -eq 1 ]; then
    echo "${YELLOW}-- Cerrando instancias en ejecución...${NC}"
    kill_processes
fi

# --- Backup del binario viejo (por si el upgrade falla) ---
if [ $UPGRADE -eq 1 ]; then
    BACKUP="$INSTALL_DIR/$BIN_NAME.backup-$(date +%s)"
    cp -a "$INSTALL_DIR/$BIN_NAME" "$BACKUP"
    echo "  Backup binario viejo: $BACKUP"
fi

# --- Copiar bundle (preservando datos si existen) ---
echo "${YELLOW}-- Instalando en $INSTALL_DIR ...${NC}"
mkdir -p "$INSTALL_DIR"

# Ficheros del bundle a copiar (todo excepto los datos del usuario)
for item in "$BIN_NAME" firefox icon.png icon.ico version.txt TecnoTactilNegocio.desktop INSTALL.md; do
    if [ -e "$SRC/$item" ]; then
        # rm previo del destino: si es dir (firefox) hay que borrarlo para no mezclar
        rm -rf "$INSTALL_DIR/$item"
        cp -a "$SRC/$item" "$INSTALL_DIR/"
    fi
done
chmod +x "$INSTALL_DIR/$BIN_NAME"

# --- Entrada .desktop con ruta absoluta ---
echo "${YELLOW}-- Registrando en el menú aplicaciones...${NC}"
mkdir -p "$DESKTOP_DIR"
if [ -f "$INSTALL_DIR/TecnoTactilNegocio.desktop" ]; then
    sed "s|%INSTALL_DIR%|$INSTALL_DIR|g" "$INSTALL_DIR/TecnoTactilNegocio.desktop" > "$DESKTOP_FILE"
    chmod +x "$DESKTOP_FILE"
fi
update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true

# --- Enlace en el PATH del user (opcional pero útil) ---
if [ "$SCOPE" = "user" ] && [ ! -e "$HOME/.local/bin/$BIN_NAME" ]; then
    mkdir -p "$HOME/.local/bin"
    ln -sf "$INSTALL_DIR/$BIN_NAME" "$HOME/.local/bin/$BIN_NAME"
fi
if [ "$SCOPE" = "system" ]; then
    ln -sf "$INSTALL_DIR/$BIN_NAME" "/usr/local/bin/$BIN_NAME"
fi

# --- Copiar uninstaller a la carpeta de instalación (para desinstalar más tarde) ---
if [ -f "$SRC/uninstall.sh" ]; then
    cp -a "$SRC/uninstall.sh" "$INSTALL_DIR/"
    chmod +x "$INSTALL_DIR/uninstall.sh"
fi

# --- Borrar backup si el upgrade fue OK ---
if [ $UPGRADE -eq 1 ]; then
    rm -f "$INSTALL_DIR/$BIN_NAME.backup-"*
fi

echo ""
echo "${GREEN}${BOLD}✅ $APP_NAME instalado correctamente.${NC}"
echo ""
if [ $UPGRADE -eq 1 ]; then
    echo "  Modo: ACTUALIZACIÓN (versión $OLD_VERSION → nueva)"
    echo "  Tus datos (BD, negocios, ventas) NO se han tocado."
else
    echo "  Modo: instalación limpia"
fi
echo ""
echo "  Ejecuta desde el menú aplicaciones (categoría Oficina)"
echo "  o desde terminal:  $BIN_NAME"
echo ""
echo "  Para DESINSTALAR:  bash $INSTALL_DIR/uninstall.sh"
