# TecnoTáctil Negocio v2.6.1 — Linux

## Instalación rápida (por usuario)

```bash
# 1) Copia esta carpeta a un lugar estable (ej. ~/.local/share/tecnotactil/)
mkdir -p ~/.local/share/tecnotactil
cp -r TecnoTactilNegocio ~/.local/share/tecnotactil/

# 2) Registra la app en el menú (sustituye %INSTALL_DIR% por la ruta real)
INSTALL_DIR=$HOME/.local/share/tecnotactil/TecnoTactilNegocio
mkdir -p ~/.local/share/applications
sed "s|%INSTALL_DIR%|$INSTALL_DIR|g" $INSTALL_DIR/TecnoTactilNegocio.desktop \
    > ~/.local/share/applications/TecnoTactilNegocio.desktop
update-desktop-database ~/.local/share/applications/ 2>/dev/null || true
```

## Ejecutar
Desde el menú aplicaciones (categoría *Oficina*) o directamente:

```bash
~/.local/share/tecnotactil/TecnoTactilNegocio/tecnotactil-negocio
```

## Firefox
- Si esta carpeta trae `firefox/` embebido, la app lo usa automáticamente.
- Si no, la app busca el Firefox del sistema (`firefox` o `firefox-esr`) en el PATH.
- Alternativa: exporta `TT_FIREFOX_BIN=/ruta/a/firefox` antes de lanzar.

## Datos
Se guardan en `$XDG_DATA_HOME/tecnotactil/negocio/` (por defecto
`~/.local/share/tecnotactil/negocio/`). Contiene la BD SQLite del negocio.

## Actualizar
Sustituye el binario `tecnotactil-negocio` (los datos no se tocan).
