#!/usr/bin/env bash
# ============================================================================
# TecnoTáctil Negocio — DESINSTALADOR (Linux).
#
# 1. Mata cualquier proceso de la app y del Firefox embebido.
# 2. Borra el bundle instalado (/opt/tecnotactil o ~/.local/share/tecnotactil).
# 3. Borra el .desktop y el symlink en PATH.
# 4. Pregunta si borrar TAMBIÉN los datos del usuario (BD del negocio).
#
# Uso:
#   bash uninstall.sh            # interactivo (pregunta sobre datos)
#   bash uninstall.sh --purge    # sin preguntar: borra TODO (incl. BD)
#   bash uninstall.sh --keep-data # borra la app, conserva la BD
# ============================================================================
set -euo pipefail

APP_ID="tecnotactil-negocio"
APP_NAME="TecnoTáctil Negocio"
BIN_NAME="tecnotactil-negocio"

BOLD=$(tput bold 2>/dev/null || echo ""); NC=$(tput sgr0 2>/dev/null || echo "")
YELLOW=$(tput setaf 3 2>/dev/null || echo ""); GREEN=$(tput setaf 2 2>/dev/null || echo "")
CYAN=$(tput setaf 6 2>/dev/null || echo ""); RED=$(tput setaf 1 2>/dev/null || echo "")

MODE="ask"
while [ $# -gt 0 ]; do
    case "$1" in
        --purge) MODE="purge"; shift ;;
        --keep-data) MODE="keep"; shift ;;
        -h|--help) grep -E '^# ' "$0" | sed 's/^# //'; exit 0 ;;
        *) echo "Opción desconocida: $1"; exit 1 ;;
    esac
done

# --- Localizar la instalación (system o user) ---
CANDIDATES=(
    "/opt/tecnotactil/TecnoTactilNegocio"
    "$HOME/.local/share/tecnotactil/TecnoTactilNegocio"
)
INSTALL_DIR=""
for c in "${CANDIDATES[@]}"; do
    if [ -x "$c/$BIN_NAME" ]; then
        INSTALL_DIR="$c"
        break
    fi
done
if [ -z "$INSTALL_DIR" ]; then
    echo "${YELLOW}No se encontró instalación en las rutas conocidas.${NC}"
    echo "Rutas revisadas:"
    printf '  %s\n' "${CANDIDATES[@]}"
    exit 1
fi

# Determinar scope y ruta del .desktop
if [[ "$INSTALL_DIR" == /opt/* ]]; then
    SCOPE="system"
    DESKTOP_FILE="/usr/share/applications/TecnoTactilNegocio.desktop"
    PATH_LINK="/usr/local/bin/$BIN_NAME"
    if [ "$(id -u)" != "0" ]; then
        echo "${RED}La instalación está en $INSTALL_DIR (sistema). Ejecuta con sudo.${NC}" >&2
        exit 1
    fi
else
    SCOPE="user"
    DESKTOP_FILE="$HOME/.local/share/applications/TecnoTactilNegocio.desktop"
    PATH_LINK="$HOME/.local/bin/$BIN_NAME"
fi

echo "${BOLD}${CYAN}== $APP_NAME — Desinstalador ==${NC}"
echo "  Instalación detectada: $INSTALL_DIR  (scope $SCOPE)"

# --- Ubicación de los datos del user ---
DATA_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/tecnotactil/negocio"
DATA_EXISTS=0
if [ -d "$DATA_DIR" ]; then
    DATA_EXISTS=1
    DATA_SIZE=$(du -sh "$DATA_DIR" 2>/dev/null | cut -f1)
    echo "  Datos del negocio en: $DATA_DIR  ($DATA_SIZE)"
fi

# --- 1) Matar procesos ---
kill_processes() {
    echo "${YELLOW}-- Cerrando procesos activos...${NC}"
    local killed=0
    local target_bin="$INSTALL_DIR/$BIN_NAME"
    local target_ff="$INSTALL_DIR/firefox/firefox"

    # SIGTERM primero
    for pattern in "$target_bin" "$target_ff"; do
        for pid in $(pgrep -f "$pattern" 2>/dev/null || true); do
            echo "  → SIGTERM PID $pid"
            kill "$pid" 2>/dev/null || true
            killed=1
        done
    done
    if [ $killed -eq 1 ]; then
        sleep 2
        # Los que sigan → SIGKILL
        for pattern in "$target_bin" "$target_ff"; do
            for pid in $(pgrep -f "$pattern" 2>/dev/null || true); do
                echo "  → SIGKILL PID $pid"
                kill -9 "$pid" 2>/dev/null || true
            done
        done
    else
        echo "  (no había procesos activos)"
    fi
}
kill_processes

# --- 2) Decidir qué hacer con los datos ---
DELETE_DATA=0
if [ $DATA_EXISTS -eq 1 ]; then
    case "$MODE" in
        purge) DELETE_DATA=1 ;;
        keep)  DELETE_DATA=0 ;;
        ask)
            echo ""
            echo "${YELLOW}${BOLD}¿Borrar TAMBIÉN los datos del negocio?${NC}"
            echo "  Sí (s) → se pierde la BD, ventas, negocios configurados. IRREVERSIBLE."
            echo "  No (N) → se conserva $DATA_DIR (recuperable al reinstalar)."
            read -r -p "  Borrar datos? [s/N]: " ans
            [ "$ans" = "s" ] || [ "$ans" = "S" ] && DELETE_DATA=1
            ;;
    esac
fi

# --- 3) Borrar bundle instalado ---
echo "${YELLOW}-- Borrando bundle $INSTALL_DIR ...${NC}"
rm -rf "$INSTALL_DIR"

# Si la carpeta padre queda vacía (p.ej. /opt/tecnotactil) → limpiarla también
parent="$(dirname "$INSTALL_DIR")"
if [ -d "$parent" ] && [ -z "$(ls -A "$parent")" ]; then
    rmdir "$parent" 2>/dev/null || true
fi

# --- 4) Borrar .desktop y symlink PATH ---
if [ -f "$DESKTOP_FILE" ]; then
    echo "  → $DESKTOP_FILE"
    rm -f "$DESKTOP_FILE"
fi
update-desktop-database "$(dirname "$DESKTOP_FILE")" 2>/dev/null || true

if [ -L "$PATH_LINK" ]; then
    echo "  → $PATH_LINK"
    rm -f "$PATH_LINK"
fi

# --- 5) Borrar datos si el user lo pidió ---
if [ $DELETE_DATA -eq 1 ]; then
    echo "${RED}-- Borrando datos del negocio en $DATA_DIR ...${NC}"
    rm -rf "$DATA_DIR"
    # Si el padre queda vacío (~/.local/share/tecnotactil/) → limpiar
    parent="$(dirname "$DATA_DIR")"
    if [ -d "$parent" ] && [ -z "$(ls -A "$parent")" ]; then
        rmdir "$parent" 2>/dev/null || true
    fi
fi

echo ""
echo "${GREEN}${BOLD}✅ $APP_NAME desinstalado.${NC}"
if [ $DATA_EXISTS -eq 1 ] && [ $DELETE_DATA -eq 0 ]; then
    echo "   Los datos del negocio quedan en $DATA_DIR (para una futura reinstalación)."
fi
