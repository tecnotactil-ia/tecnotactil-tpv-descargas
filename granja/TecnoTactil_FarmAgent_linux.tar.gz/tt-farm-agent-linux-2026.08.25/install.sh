#!/usr/bin/env bash
# install.sh — Instala el Agente-PC de granja como servicio systemd.
# Uso:  sudo ./install.sh
set -euo pipefail

PREFIX="/opt/tt-farm-agent"
CFG="/etc/tt-farm-agent"
SERVICE="/etc/systemd/system/tt-farm-agent.service"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ "$(id -u)" -eq 0 ] || { echo "Ejecuta con sudo."; exit 1; }

echo "== Instalando en $PREFIX =="
mkdir -p "$PREFIX" "$CFG"
# Parar el servicio si ya existe: si el binario está en uso, `cp` falla con
# "fichero de texto ocupado". Así una reinstalación (actualización) no revienta.
if systemctl list-unit-files 2>/dev/null | grep -q '^tt-farm-agent\.service'; then
    echo "   parando servicio existente para poder actualizar el binario…"
    systemctl stop tt-farm-agent 2>/dev/null || true
fi
cp -r "$HERE/app/." "$PREFIX/"

# Config: no se sobreescribe si ya existe (guarda el token/llave del granjero).
if [ ! -f "$CFG/agent_config.json" ]; then
    cp "$HERE/agent_config.example.json" "$CFG/agent_config.json"
    echo "   Creado $CFG/agent_config.json — EDÍTALO (pega el token de la granja) antes de arrancar."
else
    echo "   $CFG/agent_config.json ya existe, respetado."
fi

cat > "$SERVICE" <<EOF
[Unit]
Description=Agente-PC de granja TecnoTactil (tt-farm)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=AGENT_CONFIG=$CFG/agent_config.json
Environment=AGENT_STATE=$CFG/agent_state.json
ExecStart=$PREFIX/tt-farm-agent
Restart=always
RestartSec=15

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable tt-farm-agent

# Si la config ya tiene token (reinstalación/actualización), arrancar solo.
if grep -q '"token"[[:space:]]*:[[:space:]]*"[^"]\{20,\}"' "$CFG/agent_config.json" 2>/dev/null; then
    systemctl restart tt-farm-agent
    echo ""
    echo "LISTO y ARRANCADO (token ya configurado). Ver el heartbeat:"
    echo "  journalctl -u tt-farm-agent -f"
else
    echo ""
    echo "LISTO. Ahora:"
    echo "  1) edita $CFG/agent_config.json  (pega el token de la granja)"
    echo "  2) sudo systemctl start tt-farm-agent"
    echo "  3) journalctl -u tt-farm-agent -f   (ver el heartbeat)"
fi
