#!/usr/bin/env bash
# install.sh — Instala el Agente-PC de granja como servicio systemd.
# Uso:  sudo ./install.sh
set -euo pipefail

PREFIX="/opt/tt-farm-agent"
CFG="/etc/tt-farm-agent"
SERVICE="/etc/systemd/system/tt-farm-agent.service"
HERE="$(cd "$(dirname "$0")" && pwd)"

[ "$(id -u)" -eq 0 ] || { echo "Ejecuta con sudo."; exit 1; }

echo "== Instalando en $PREFIX =="
mkdir -p "$PREFIX" "$CFG"
cp -r "$HERE/app/." "$PREFIX/"

# Config: no se sobreescribe si ya existe (guarda el token/llave del granjero).
if [ ! -f "$CFG/agent_config.json" ]; then
    cp "$HERE/agent_config.example.json" "$CFG/agent_config.json"
    echo "   Creado $CFG/agent_config.json — EDÍTALO (service_key, farm_name) antes de arrancar."
else
    echo "   $CFG/agent_config.json ya existe, respetado."
fi

cat > "$SERVICE" <<EOF
[Unit]
Description=Agente-PC de granja TecnoTactil (tt-farm)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
Environment=AGENT_CONFIG=$CFG/agent_config.json
Environment=AGENT_STATE=$CFG/agent_state.json
ExecStart=$PREFIX/tt-farm-agent
Restart=always
RestartSec=15

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable tt-farm-agent
echo ""
echo "LISTO. Ahora:"
echo "  1) edita $CFG/agent_config.json  (service_key + farm_name)"
echo "  2) sudo systemctl start tt-farm-agent"
echo "  3) journalctl -u tt-farm-agent -f   (ver el heartbeat)"
