# Descargas TecnoTactil

Un regalo de [TecnoTactil](https://www.tecnotactil.com): baja vídeo, audio y
fotos de **YouTube, TikTok, Instagram, X, Facebook, Reddit, SoundCloud,
Pinterest y más de 20 plataformas** — desde tu propio PC, sin anuncios, sin
rastreadores y sin páginas raras.

## Instalar (Linux)

```bash
tar xzf descargas-tt-1.0.tar.gz
cd descargas-tt
./instalar.sh
```

Se instala solo para tu usuario (sin sudo). Luego búscala en el menú de
aplicaciones como **Descargas TecnoTactil**, o desde la terminal:

```bash
descargas-tt                 # interfaz gráfica
descargas-tt --cli <enlace>  # descarga directa por consola
```

Para desinstalar: `./instalar.sh --quitar`

## Cómo funciona

Pegas el enlace, eliges **Vídeo / Solo audio (MP3) / Vídeo sin audio** y la
calidad, y el fichero cae en tu carpeta de Descargas. Por dentro lleva una
cadena de motores que se prueban solos, en tu propia máquina:

1. **[cobalt](https://github.com/imputnet/cobalt)** autoalojado (si tienes
   Docker, el instalador lo deja corriendo en `localhost:9000`).
2. **yt-dlp** de respaldo.
3. Si la plataforma pide sesión iniciada, reintento automático con las cookies
   de tu propio navegador (Chrome, Firefox, Chromium, Brave o Edge) — tus
   cookies nunca salen de tu PC.

## Requisitos

- Linux con Python 3 y GTK4 (`python3-gi` + `gir1.2-gtk-4.0` o equivalente).
- `yt-dlp` (el instalador te dice el comando exacto de tu distribución).
- Docker (opcional, para el motor cobalt; sin él la app funciona igual).

## Uso responsable

Descarga solo contenido público y respeta los derechos de autor y las
condiciones de cada plataforma. La herramienta es para uso personal
(guardarte una copia de lo que ya puedes ver), no para republicar contenido
ajeno.
