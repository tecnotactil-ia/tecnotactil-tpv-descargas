#!/usr/bin/env bash
# Instalador de Descargas TecnoTactil — un regalo de TecnoTactil
# (www.tecnotactil.com). Baja vídeo, audio y fotos de YouTube, TikTok,
# Instagram, X, Facebook, Reddit y más, desde tu propio PC y sin anuncios.
#
# Uso:   ./instalar.sh              instala para tu usuario (sin sudo)
#        ./instalar.sh --quitar     desinstala
set -euo pipefail
AQUI="$(cd "$(dirname "$0")" && pwd)"
BIN="$HOME/.local/bin"
APPS="$HOME/.local/share/applications"
ICONOS="$HOME/.local/share/icons/hicolor/scalable/apps"

if [ "${1:-}" = "--quitar" ]; then
    rm -f "$BIN/descargas-tt" "$APPS/descargas-tt.desktop" "$ICONOS/descargas-tt.svg"
    docker rm -f cobalt-tt >/dev/null 2>&1 || true
    rm -rf "$HOME/.config/cobalt-tt"
    echo "Descargas TecnoTactil desinstalada. ¡Hasta pronto!"
    exit 0
fi

echo "== Descargas TecnoTactil =="

# --- requisitos ---
falta=0
if ! python3 -c 'import gi; gi.require_version("Gtk","4.0")' 2>/dev/null; then
    echo "FALTA: Python GTK4. Instálalo con tu gestor de paquetes:"
    echo "   Debian/Ubuntu:  sudo apt install python3-gi gir1.2-gtk-4.0"
    echo "   Fedora:         sudo dnf install python3-gobject gtk4"
    echo "   Arch/CachyOS:   sudo pacman -S python-gobject gtk4"
    falta=1
fi
if ! command -v yt-dlp >/dev/null; then
    echo "FALTA: yt-dlp (motor de respaldo). Instálalo con tu gestor de paquetes:"
    echo "   Debian/Ubuntu:  sudo apt install yt-dlp     ·  Fedora: sudo dnf install yt-dlp"
    echo "   Arch/CachyOS:   sudo pacman -S yt-dlp"
    falta=1
fi
[ $falta -eq 1 ] && { echo; echo "Instala lo que falta y vuelve a ejecutar ./instalar.sh"; exit 1; }

# --- ficheros ---
mkdir -p "$BIN" "$APPS" "$ICONOS"
install -m 755 "$AQUI/descargas-tt" "$BIN/descargas-tt"
install -m 644 "$AQUI/descargas-tt.svg" "$ICONOS/descargas-tt.svg"
sed "s|^Exec=.*|Exec=$BIN/descargas-tt|" "$AQUI/descargas-tt.desktop" > "$APPS/descargas-tt.desktop"
update-desktop-database "$APPS" 2>/dev/null || true

# --- motor cobalt (opcional: solo si hay docker) ---
if command -v docker >/dev/null && docker info >/dev/null 2>&1; then
    mkdir -p "$HOME/.config/cobalt-tt"
    if [ ! -f "$HOME/.config/cobalt-tt/docker-compose.yml" ]; then
        cat > "$HOME/.config/cobalt-tt/docker-compose.yml" <<'EOF'
# Instancia LOCAL de cobalt para Descargas TecnoTactil.
# Solo escucha en localhost: no se expone a la red.
services:
  cobalt-api:
    image: ghcr.io/imputnet/cobalt:11
    container_name: cobalt-tt
    restart: unless-stopped
    ports:
      - "127.0.0.1:9000:9000"
    environment:
      API_URL: "http://127.0.0.1:9000/"
      DURATION_LIMIT: "36000"
EOF
    fi
    docker compose -f "$HOME/.config/cobalt-tt/docker-compose.yml" up -d >/dev/null 2>&1 \
        && echo "Motor cobalt: activado (docker, localhost:9000)." \
        || echo "Motor cobalt: no se pudo arrancar; la app usará yt-dlp igualmente."
else
    echo "Motor cobalt: sin docker en este equipo; la app funciona igual con yt-dlp."
fi

echo
echo "¡Instalada! Búscala en el menú como \"Descargas TecnoTactil\""
echo "o ejecútala con:  descargas-tt   (también: descargas-tt --cli <url>)"
