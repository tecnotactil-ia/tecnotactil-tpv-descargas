#!/usr/bin/env bash
# Instala Vídeos pal Carro en ~/.local (igual que bajar-videos-tecnotactil)
set -euo pipefail
AQUI="$(cd "$(dirname "$0")" && pwd)"

install -Dm755 "$AQUI/convertir-video"     "$HOME/.local/bin/convertir-video"
install -Dm755 "$AQUI/convertir-video-gui" "$HOME/.local/bin/convertir-video-gui"
install -Dm644 "$AQUI/videos-carro-tt.svg" "$HOME/.local/share/icons/hicolor/scalable/apps/videos-carro-tt.svg"
install -Dm644 "$AQUI/videos-carro.desktop" "$HOME/.local/share/applications/videos-carro.desktop"
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true

echo "✔ Instalado. Búscalo en el menú como «Vídeos pal Carro»"
echo "  o por terminal: convertir-video-gui / convertir-video <archivo>"
