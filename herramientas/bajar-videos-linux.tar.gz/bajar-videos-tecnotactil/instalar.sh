#!/usr/bin/env bash
# Instalador de "Bajar Vídeos" — un regalo de TecnoTactil (www.tecnotactil.com)
# Funciona en Arch/Manjaro/CachyOS, Debian/Ubuntu/Mint y Fedora.
set -euo pipefail
cd "$(dirname "$0")"

echo "╔══════════════════════════════════════════════╗"
echo "║   Bajar Vídeos — un regalo de TecnoTactil    ║"
echo "║          www.tecnotactil.com                 ║"
echo "╚══════════════════════════════════════════════╝"
echo

# ── 1. Dependencias ──────────────────────────────────────────────
falta=0
command -v yt-dlp  >/dev/null || falta=1
command -v ffmpeg  >/dev/null || falta=1
python3 -c "import gi; gi.require_version('Gtk','4.0')" 2>/dev/null || falta=1

if [ "$falta" -eq 1 ]; then
    echo "→ Instalando dependencias (te pedirá tu contraseña)..."
    if command -v pacman >/dev/null; then
        sudo pacman -S --needed --noconfirm yt-dlp ffmpeg python-gobject gtk4
    elif command -v apt >/dev/null; then
        sudo apt update && sudo apt install -y yt-dlp ffmpeg python3-gi gir1.2-gtk-4.0
    elif command -v dnf >/dev/null; then
        sudo dnf install -y yt-dlp ffmpeg python3-gobject gtk4
    else
        echo "✖ No reconozco tu distribución. Instala a mano: yt-dlp, ffmpeg, python-gobject y GTK4."
        exit 1
    fi
else
    echo "✔ Dependencias ya instaladas."
fi

# ── 2. Copiar la aplicación ──────────────────────────────────────
mkdir -p "$HOME/.local/bin" \
         "$HOME/.local/share/applications" \
         "$HOME/.local/share/icons/hicolor/scalable/apps"

install -m 755 bajar-video bajar-video-gui "$HOME/.local/bin/"
install -m 644 bajar-videos-tt.svg "$HOME/.local/share/icons/hicolor/scalable/apps/"

cat > "$HOME/.local/share/applications/bajar-videos.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Bajar Vídeos — TecnoTactil
Comment=Descarga vídeos de YouTube y mil sitios más. Un regalo de TecnoTactil — www.tecnotactil.com
Exec=$HOME/.local/bin/bajar-video-gui
Icon=bajar-videos-tt
Terminal=false
Categories=AudioVideo;Network;
Keywords=video;descargar;youtube;tecnotactil;
EOF

update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true

echo
echo "✔ ¡Instalado! Busca «Bajar Vídeos» en tu menú de aplicaciones."
echo "  También puedes usarlo desde la terminal: bajar-video <enlace>"
echo
echo "  Cortesía de TecnoTactil — www.tecnotactil.com"
echo "  TPV punto de venta · monedero con recargas CUP/QvaPay · soluciones digitales"
